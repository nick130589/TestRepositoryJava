package com.hillel.lesson14.abstractClassDemo.firstOption;

public class Child {
}
