package com.hillel.lesson14.abstractClassDemo.secondOption;

public class Woman extends Person {

    public Woman(String name, String surname) {
        super(name, surname);
    }
}
