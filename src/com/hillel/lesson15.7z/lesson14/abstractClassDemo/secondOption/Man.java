package com.hillel.lesson14.abstractClassDemo.secondOption;

public class Man extends Person {

    public Man(String name, String surname) {
        super(name, surname);
    }
}
