package com.hillel.lesson14.collections.linkedListDemo;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class LinkedDemo {
    public static void main(String[] args) {
        LinkedList<String> list = new LinkedList<>();

        list.add("Privet");
        list.add("Guys");

        list.get(1);

        System.out.println(list);

        list.addFirst("Genya");

        System.out.println(list);

        List<String> arrayList = new ArrayList();
        arrayList.add("Test");
        arrayList.add("Test2");
        arrayList.add(0, "Privet");
        System.out.println(arrayList);
    }

}
