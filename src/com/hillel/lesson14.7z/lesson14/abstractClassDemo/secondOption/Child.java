package com.hillel.lesson14.abstractClassDemo.secondOption;

public class Child extends Person {
    public Child(String name, String surname) {
        super(name, surname);
    }
}
